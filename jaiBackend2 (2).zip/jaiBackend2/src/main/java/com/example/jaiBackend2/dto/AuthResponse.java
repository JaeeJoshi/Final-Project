package com.example.jaiBackend2.dto;

public class AuthResponse {

}
