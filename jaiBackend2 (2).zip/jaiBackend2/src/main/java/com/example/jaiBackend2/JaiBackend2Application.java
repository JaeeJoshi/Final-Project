package com.example.jaiBackend2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JaiBackend2Application {

	public static void main(String[] args) {
		SpringApplication.run(JaiBackend2Application.class, args);
	}

}
